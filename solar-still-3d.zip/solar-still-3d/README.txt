Solar Still 3D Model

Open index.html through a local web server or publish this folder with GitHub Pages. The page loads Three.js from jsDelivr, so an internet connection is needed to display the 3D scene.

Controls
- Drag to rotate the model; scroll or pinch to zoom.
- Select a component in the list or on the model to read its description.
- Use the buttons to pause flow, switch the process simulation off/on, hide labels, or reset the camera.

The treatment line shows a sediment polishing cartridge, activated carbon, optional remineralization, and UV disinfection after distillation. These are illustrative stages, not a drinking-water safety certification. Actual safety depends on source water, equipment design, maintenance, and water testing.
